package com.cg.capbook.beans;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class ForumComment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int forumCommentId;
	private String commentBody;
	private int postedBy;
	private LocalDateTime dateOfPosting;
	private int likeCount;
	private int dislikeCount;
	@ManyToOne
	private ForumPost forumPost;
	
	public ForumComment() {}

	public ForumComment(String commentBody, int postedBy, LocalDateTime dateOfPosting, int likeCount, int dislikeCount,
			ForumPost forumPost) {
		super();
		this.commentBody = commentBody;
		this.postedBy = postedBy;
		this.dateOfPosting = dateOfPosting;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.forumPost = forumPost;
	}

	public ForumComment(String commentBody, int postedBy, LocalDateTime dateOfPosting, int likeCount,
			int dislikeCount) {
		super();
		this.commentBody = commentBody;
		this.postedBy = postedBy;
		this.dateOfPosting = dateOfPosting;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}

	public int getForumCommentId() {
		return forumCommentId;
	}

	public void setForumCommentId(int forumCommentId) {
		this.forumCommentId = forumCommentId;
	}

	public String getCommentBody() {
		return commentBody;
	}

	public void setCommentBody(String commentBody) {
		this.commentBody = commentBody;
	}

	public int getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(int postedBy) {
		this.postedBy = postedBy;
	}

	public LocalDateTime getDateOfPosting() {
		return dateOfPosting;
	}

	public void setDateOfPosting(LocalDateTime dateOfPosting) {
		this.dateOfPosting = dateOfPosting;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public int getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	public ForumPost getForumPost() {
		return forumPost;
	}

	public void setForumPost(ForumPost forumPost) {
		this.forumPost = forumPost;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((commentBody == null) ? 0 : commentBody.hashCode());
		result = prime * result + ((dateOfPosting == null) ? 0 : dateOfPosting.hashCode());
		result = prime * result + dislikeCount;
		result = prime * result + forumCommentId;
		result = prime * result + ((forumPost == null) ? 0 : forumPost.hashCode());
		result = prime * result + likeCount;
		result = prime * result + postedBy;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ForumComment other = (ForumComment) obj;
		if (commentBody == null) {
			if (other.commentBody != null)
				return false;
		} else if (!commentBody.equals(other.commentBody))
			return false;
		if (dateOfPosting == null) {
			if (other.dateOfPosting != null)
				return false;
		} else if (!dateOfPosting.equals(other.dateOfPosting))
			return false;
		if (dislikeCount != other.dislikeCount)
			return false;
		if (forumCommentId != other.forumCommentId)
			return false;
		if (forumPost == null) {
			if (other.forumPost != null)
				return false;
		} else if (!forumPost.equals(other.forumPost))
			return false;
		if (likeCount != other.likeCount)
			return false;
		if (postedBy != other.postedBy)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ForumComment [forumCommentId=" + forumCommentId + ", commentBody=" + commentBody + ", postedBy="
				+ postedBy + ", dateOfPosting=" + dateOfPosting + ", likeCount=" + likeCount + ", dislikeCount="
				+ dislikeCount + "]";
	}

	
}
