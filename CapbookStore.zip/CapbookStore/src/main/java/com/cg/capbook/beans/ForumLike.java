package com.cg.capbook.beans;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class ForumLike {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ForumLikeId;
	private int likedBy;
	private LocalDateTime dateOfLike;
	@ManyToOne
	private ForumPost forumPost;
	
	public ForumLike() {}

	public ForumLike(int likedBy, LocalDateTime dateOfLike, ForumPost forumPost) {
		super();
		this.likedBy = likedBy;
		this.dateOfLike = dateOfLike;
		this.forumPost = forumPost;
	}

	public ForumLike(int likedBy, LocalDateTime dateOfLike) {
		super();
		this.likedBy = likedBy;
		this.dateOfLike = dateOfLike;
	}

	public int getForumLikeId() {
		return ForumLikeId;
	}

	public void setForumLikeId(int forumLikeId) {
		ForumLikeId = forumLikeId;
	}

	public int getLikedBy() {
		return likedBy;
	}

	public void setLikedBy(int likedBy) {
		this.likedBy = likedBy;
	}

	public LocalDateTime getDateOfLike() {
		return dateOfLike;
	}

	public void setDateOfLike(LocalDateTime dateOfLike) {
		this.dateOfLike = dateOfLike;
	}

	public ForumPost getForumPost() {
		return forumPost;
	}

	public void setForumPost(ForumPost forumPost) {
		this.forumPost = forumPost;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ForumLikeId;
		result = prime * result + ((dateOfLike == null) ? 0 : dateOfLike.hashCode());
		result = prime * result + ((forumPost == null) ? 0 : forumPost.hashCode());
		result = prime * result + likedBy;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ForumLike other = (ForumLike) obj;
		if (ForumLikeId != other.ForumLikeId)
			return false;
		if (dateOfLike == null) {
			if (other.dateOfLike != null)
				return false;
		} else if (!dateOfLike.equals(other.dateOfLike))
			return false;
		if (forumPost == null) {
			if (other.forumPost != null)
				return false;
		} else if (!forumPost.equals(other.forumPost))
			return false;
		if (likedBy != other.likedBy)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ForumLike [ForumLikeId=" + ForumLikeId + ", likedBy=" + likedBy + ", dateOfLike=" + dateOfLike + "]";
	}

	
	
}
