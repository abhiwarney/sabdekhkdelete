package com.cg.capbook.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.services.LoginService;
import com.cg.capbook.services.PasswordServices;
import com.cg.capbook.services.UserProfileServices;

@Controller
@SessionAttributes("user")
public class CapbookServiceController {

	@Autowired
	UserProfileServices capbookServices;
	@Autowired
	PasswordServices passwordServices;
	@Autowired
	LoginService loginService;
	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute UserProfile user) {
		UserProfile user1=capbookServices.acceptUserProfileDetails(user);
		return new ModelAndView("dashboard","user",user1);
	}
	@RequestMapping("/login")
	public ModelAndView loginUser(@RequestParam String email,String password) {
		return new ModelAndView("dashboard","user",	loginService.loginUser(email, password));
	}
	@RequestMapping("/forgotPassword")
	public ModelAndView forgotPassword(@RequestParam String email,String securityQuestion,String securityAnswer) {
		String password=passwordServices.forgotUserPassword(email, securityQuestion, securityAnswer);
		return new ModelAndView("forgotPasswordPage","password",password);
	}
	@RequestMapping("/changePassword")
	public ModelAndView changePassword(@SessionAttribute("user") UserProfile user,@RequestParam String newPassword,String currentPassword) {
		passwordServices.changeUserPassword(user.getUserId(), newPassword, currentPassword);
		return new ModelAndView("dashboard","user",capbookServices.getUserProfileDetails(user.getUserId()));
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(SessionStatus status) {
		status.setComplete();
		return "indexPage";
	}

}

