package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.ForumComment;

public interface ForumCommentDao extends JpaRepository<ForumComment, Integer>{

}
