package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.Forum;

public interface ForumDao extends JpaRepository<Forum, Integer>{

}
