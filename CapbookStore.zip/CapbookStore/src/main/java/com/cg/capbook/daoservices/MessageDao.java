package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.Messages;

public interface MessageDao extends JpaRepository<Messages, Integer>{

}
