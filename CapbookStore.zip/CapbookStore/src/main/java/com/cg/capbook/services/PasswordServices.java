package com.cg.capbook.services;

public interface PasswordServices { 
	String forgotUserPassword(String emailId,String securityQuestion,String securityAnswer);
	boolean changeUserPassword(int userId,String newPassword,String currentPassword);
}
